Register definition (.h) files for Sharp ARM based MCUs
-------------------------------------------------------

Header files for Sharp ARM Based MCUs can be downloaded from the 
BlueStreak software library web-site. Currently at:

http://able.sharpsma.com

Also available are drivers and Board Support Packages.

(Requires registration, but should be free.)