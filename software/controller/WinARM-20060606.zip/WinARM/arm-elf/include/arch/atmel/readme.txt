Register definition (.h) files for Atmel ARM based MCUs
-------------------------------------------------------

at91x40.h - Atmel AT91x40 series: AT91M40800,  AT91R40807, AT91M40807,
                                  AT91R40008,  AT91FR4081, AT91F40816,
                                  AT91FR40162, AT91FR4042

at91rm9200.h - Atmel AT91RM9200

at91m55800a.h - Atmel AT91M55800A
