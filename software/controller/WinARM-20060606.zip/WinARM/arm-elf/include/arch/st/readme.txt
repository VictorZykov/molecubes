Register definition (.h) files for STMicroelectronics ARM based MCUs
--------------------------------------------------------------------

str71x (directory) - ST STR710, STR711, STR712
                     These files are copied from the ST web site

