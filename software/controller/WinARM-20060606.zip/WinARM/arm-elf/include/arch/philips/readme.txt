Register definition (.h) files for Philips ARM based MCUs
---------------------------------------------------------

lpc2000.h - LPC2000 series - defines a register "super set".

lpc210x.h - Philips LPC2104, LPC2105 and LPC2106 - extende with MAM-Registers - mthomas

lpc2114.h - Philips LPC2014, LPC2024

lpc2119.h - Philips LPC2119, LPC2129, LPC2290, LPC2292, LPC2294

lpc221x.h - same as lpc2114.h (by using #include)

lpc229x.h - same as lpc2119.h (by using #include)