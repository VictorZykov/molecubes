#ifndef Time_h
#define Time_h

extern void init_timer  (void);             /* Initialize Timer */
extern volatile unsigned long timeval;      /* Current Time Tick */

#endif
