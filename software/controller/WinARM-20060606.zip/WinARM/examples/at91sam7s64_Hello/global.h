#ifndef global_h_
#define global_h_

#include "AT91SAM7S64.h"

extern AT91S_PIO * pPIO;

#endif
