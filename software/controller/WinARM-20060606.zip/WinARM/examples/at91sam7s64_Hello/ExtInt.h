#ifndef ExtInt_h_
#define ExtInt_h_

extern void init_extint(void);

#endif
