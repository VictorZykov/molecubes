extern volatile unsigned long timeval;

extern void init_timer(void);
