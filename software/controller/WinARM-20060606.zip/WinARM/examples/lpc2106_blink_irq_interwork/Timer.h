extern volatile unsigned long timeval;

void __attribute__ ((interrupt("IRQ"))) tc0_cmp(void);
