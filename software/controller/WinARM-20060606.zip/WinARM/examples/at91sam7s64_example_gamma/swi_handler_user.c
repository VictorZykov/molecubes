/* User SWI Handler for SWI's not handled in swi_handler.S */

#include <stdio.h>
#include "Board.h"
#include "dbgu.h"

unsigned long SWI_Handler_User(unsigned long reg0,
	unsigned long reg1,
	unsigned long reg2,
	unsigned long swi_num )
{
	unsigned long res;

	res = 0;
	
	switch (swi_num) {
	case 0x10 :
		// toogle LED2
		if ((AT91F_PIO_GetInput(AT91C_BASE_PIOA) & LED2 ) == LED2 ) {
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, LED2 );
		}
		else {
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, LED2 );
		}
		res = 0xfefefefe;
		break;
	case 0x11 :
		// toogle LED3
		if ((AT91F_PIO_GetInput(AT91C_BASE_PIOA) & LED3 ) == LED3 ) {
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, LED3 );
		}
		else {
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, LED3 );
		}
		res = 0xdeadbeef;
		break;
	case 0x12 :
		res = reg0 + 1;
		break;
	default :
		break;
	} /* switch */
	
	return res;
}
