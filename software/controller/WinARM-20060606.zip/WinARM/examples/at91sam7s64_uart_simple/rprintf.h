#ifndef __PRINTF_H
#define __PRINTF_H

extern void rputs(char const *txt);
extern void rprintf(char const *fmt0, ...);

#endif
