#ifndef cstartup_sam7_h
#define cstartup_sam7_h

void AT91F_LowLevelInit( void );

#endif
