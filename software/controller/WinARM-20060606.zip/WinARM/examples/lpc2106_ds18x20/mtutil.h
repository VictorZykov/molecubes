
#ifndef MTUTIL_H_
#define MTUTIL_H_

#include "types.h"

char* itoa(int16_t i);

#endif
