

DS18x20 Demo for LPC2000 ARM7TDMI
---------------------------------
by Martin Thomas <eversmith(at)heizung-thomas.de>

A WinARM sample application for
arm-elf-gcc (tested with Ver 3.4.2).

Proto-Board: Olimex LPC-P2106 
Connect One-Wire from DS18x20 (DS18B20 used for testing)
to P0.4. Parsite Power not supported/tested so far. 
Don't forget the mandantory One-Wire Pull-Up.

Software "Skeleton", UART and headers from:
-Bill Knight, R O SoftWare, BillK@rosw.com





