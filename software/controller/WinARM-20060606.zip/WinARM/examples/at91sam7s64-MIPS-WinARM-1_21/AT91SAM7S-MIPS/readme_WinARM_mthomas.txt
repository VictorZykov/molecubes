* 
* This is a ported version of the example
* "AT91SAM7S256-MIPS-IAR4_30A_1_21"
* provided by Atmel (at91.com) to the GNU arm-elf Toolchain
*
* Porting to the GNU-toolchain and modifications done by
* Martin Thomas, Kaiserslautern, Germany
*   <mthomas@rhrk.uni-kl.de>
*   http://www.siwawi.arubi.uni-kl.de/avr_projects
*
*   Timestamp for this Version of the port: 10. May 2006
*

Atmel Rousset provides this example on 
www.at91.com -> kit -> AT91SAM7S-EK -> code for IAR

The MIPS-example has not been available for the GNU-toolchain
by the time of writing this. I have ported and modified most
of the code for the IAR-compiler to the GNU arm-elf-toolchain.

The benchmark itself is not too useful but I think the modifications
done for the GNU-toolchain can be useful for other projects. 

(I have done the port to learn more about the toolchain-internals like
assembler, assembler-macros, interwork, newlib and newlib-syscalls etc.
and did not care about the "MIPS"-values. Positive "side-effect":
some knowledge about porting from IAR to GNU - a deja vu from the
AVR Butterfly GCC-port)

- Added a makefile based on the WinARM-template
- Created a directory compil/SrcWinARM (following the Atmel-scheme)
- Startup-code and linker-scipts from Atmel-examples for Keil 
  with gcc (slightly modified)
- syscalls.c for newlib with SAM7 DBGU-interface (polled-mode)
- MIPS.mac and asm_mips.S ported to the arm-elf-as syntax
  and options (.arm,.thumb,.global,.section etc.)
- fastrun-section ("ramfunc")
- changed printf to iprintf for newlib-functions without
  floating-point-support (since FPs are not needed here) 
  -> needs less memory
- added prototype for siprintf to dgbu.c (seems to be missing
  in the newlib 1.14.0 stdio.h), changed sscanf to siscanf
  to save same memory.
  
TODOs: 
* Needs some more testing.


Cheers,
Martin
