Tracecon.exe is a very simplistic utility for converting the trace data captured by the scheduler into a tab delimited text file.  The text file can be opened using a spread sheet program as described on www.FreeRTOS.org.

Tracecon should be executed from a command prompt.  It looks for a file called Trace.bin in the current directory and creates a file called trace.txt.

Use the big endian version for file captured on big endian targets.

