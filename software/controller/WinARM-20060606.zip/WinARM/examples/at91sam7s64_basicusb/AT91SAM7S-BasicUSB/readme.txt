
This is a WinARM/arm-elf-gcc version of the
ATMEL basic-usb example.

Minor modifications have been done in the
source-code (src/-dir.) to avoid warnings and
reduce compile-time.

WinARM/arm-elf-gcc specific files have
been added in a compil/SrcWinARM-directory. 
The files are based on a example from Atmel 
for Keil/gcc and have been modified for 
"stand-alone" arm-elf-gcc with newlib as 
in WinARM.

An additional inf-file has been included
in the PC exec/inf_ser_WinARM-directory. 
This inf provides a virtual COM-port. The 
inf-file is based on a file found in
a FreeRTOS-example and has been 
modified to avoid confilicts with
the FreeRTOS example. VID and PID
have been adapated to the IDs found
in the Atmel code. The original inf-files
have been moved into subdirectorys to 
avoid confusion with different inf-files
during installation.


Some remarks also valid for the original
Atmel/IAR Example:

There are two modes imlemented in the
Demo:

-- 1 --

If USART_COM is defined in main.c.
The application "bridges" between
the virutal COM-port on USB and 
the SAM7 hardware UART. Basicly it's a 
USB to serial converter.

Settings of the virtual COM-Port:
115200,8,n,1, no FC

Settings of the SAM7-UART:
115200,8,n,1, no FC

-- 2 --

When UART_COM is not defined the
application is configured to 
communicate with the BASICUSB_6124.exe
via the USBLibrary.dll.



WinARM/arm-elf-gcc port and this readme 
done by:

Martin Thomas 11/2005
http://www.siwawi.arubi.uni-kl.de/avr_projects
<eversmith@heizung-thomas.de>
