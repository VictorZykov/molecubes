
AD�C 7026 Blinky Example for WinARM 
** PRELIMINARY - Not tested with hardware ***

Function: GPIO 4.2 Pin gets toggled (High/Low/High...).

This examples is based on code from the 
Analog Devices Developer-CD Version 1.1.

Adapted for arm-elf-gcc (WinARM) by 
Martin Thomas, Kaiserslautern, Germany
<eversmith@heizung-thomas.de>
http://www.siwawi.arubi.uni-kl.de/avr_projects

The "framework" is a "Keil-Type": initialisation 
in a single assembler-file startup.S

Build tested with WinARM 1/06. The Simulation of 
the elf-file produced by arm-elf-gcc in 
Keil's uVision ARM-simulator works as expected.



Basic procedure to upload this code 
should be like this:

- set COM-port in makefile (default COM2)
- make all
- connect bootloader-pin to GND, toggle reset
- make program (which calls lpc21isp)
- remove bootloader-pin connection
- reset target
- use oscilloscope or LED to verify that GPIO 4.2 toggles

Of cause the ADI ARMWSD.exe can be used to upload
the firmware too.


Modifications for arm-elf-gcc/WinARM:

* main.c/delay() 
 - added local volatile var to avoid loop-removal 
   when compiled with optimization 
 - parameter unsigned long
 - check for >0 (was >=0 with int parameter) 

* Register-definitions from the Analog-CD included 
  in the ./include directory

* interrupt-wrappers (irq.c) included (also copied from the CD). 
  Own Interrupt-Service-Routines can be implemented in 
  functions called by the wrappers (IRQ(), SWI() etc.)

* Makefile:
 - modified to build a AD�C ROM-target
   so far neither the RAM-target nor remapping is implemented
 - Parameters to lpc21isp adapted for the Analog UART-Bootloader

* renamed startup.s to startup.S to enable preprocessor

* The example is so small an so well optimzed, that there
  is not code in the data-section. Modifications in the
  linker-scipts and startup-code had to be done avoid
  data-abord-exceptions during startup because of the
  empty section. See comments in file. Again: not tested 
  with hardware.

* added -RAM.ld - you have guessed it: yes, also not tested

