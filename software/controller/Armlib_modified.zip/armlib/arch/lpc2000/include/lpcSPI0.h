/******************************************************************************
 *
 * $RCSfile: $
 * $Revision: $
 *
 * Header file for Philips LPC ARM Processors.
 * Copyright 2004 R O SoftWare
 *
 * No guarantees, warrantees, or promises, implied or otherwise.
 * May be used for hobby or commercial purposes provided copyright
 * notice remains intact.
 *
 *****************************************************************************/
#ifndef INC_LPC_SPI0_H
#define INC_LPC_SPI0_H

// Serial Peripheral Interface Registers (SPI0)
typedef struct
{
  REG_8 cr;                             // Control Register
  REG_8 _pad0[3];
  REG_8 sr;                             // Status Register
  REG_8 _pad1[3];
  REG_8 dr;                             // Data Register
  REG_8 _pad2[3];
  REG_8 ccr;                            // Clock Count Register
  REG_8 _pad3[3];
  REG_8 flag;                           // Interrupt Flag
  REG_8 _pad4[3];
} spi0Regs_t;

#endif
